import numpy as np
import pandas as pd
from dataclasses import dataclass
from typing import Dict, Tuple, Optional


@dataclass(frozen=True)
class SustainIndexConfig:
    # Column names
    cfe_col: str = "carbon_free_energy_percentage_cfe_avg_2025"      # maximize
    ci_col: str = "carbon_intensity_gco_eq_kwh_direct_avg_2025"      # minimize
    water_col: str = "water_risk_index_bau50"                        # minimize
    dist_col: str = "nearest_plant_dist_km"                          # minimize (exp decay)
    cap_col: str = "nearest_plant_capacity_mw"                       # maximize

    # Scaling params
    p_low: float = 5.0
    p_high: float = 95.0

    # Distance decay
    tau_km: float = 25.0

    # Weights (must sum to 1)
    weights: Dict[str, float] = None  # set in __post_init__ below

    def __post_init__(self):
        if self.weights is None:
            object.__setattr__(self, "weights", {
                "score_cfe_2025": 0.30,
                "score_ci_direct_2025": 0.25,
                "score_water_bau50": 0.25,
                "score_nearest_plant_dist": 0.15,
                "score_capacity_mw": 0.05,
            })


def robust_bounds(series: pd.Series, p_low: float = 5.0, p_high: float = 95.0) -> Tuple[float, float]:
    x = pd.to_numeric(series, errors="coerce").astype(float).to_numpy()
    x = x[np.isfinite(x)]
    if x.size == 0:
        return (np.nan, np.nan)
    lo = float(np.nanpercentile(x, p_low))
    hi = float(np.nanpercentile(x, p_high))
    return lo, hi


def robust_scale_value(x: float, lo: float, hi: float, higher_is_better: bool) -> float:
    if not np.isfinite(x) or not np.isfinite(lo) or not np.isfinite(hi) or hi == lo:
        return np.nan
    s = (x - lo) / (hi - lo)
    s = float(np.clip(s, 0.0, 1.0))
    if not higher_is_better:
        s = 1.0 - s
    return s


def robust_scale_series(series: pd.Series, lo: float, hi: float, higher_is_better: bool) -> pd.Series:
    x = pd.to_numeric(series, errors="coerce").astype(float)
    scaled = (x - lo) / (hi - lo)
    scaled = scaled.clip(0.0, 1.0)
    if not higher_is_better:
        scaled = 1.0 - scaled
    return scaled


def compute_sustainability_index_v1(
    df: pd.DataFrame,
    config: Optional[SustainIndexConfig] = None,
    bounds: Optional[Dict[str, Tuple[float, float]]] = None,
    add_component_scores: bool = True,
) -> Tuple[pd.DataFrame, Dict[str, Tuple[float, float]]]:
    """
    Compute Sustainability Index v1.

    - If bounds is None, bounds are computed over the ENTIRE df using P5/P95 per metric.
    - Returns: (df_with_scores, bounds_used)

    Component score columns (if add_component_scores=True):
      - score_cfe_2025
      - score_ci_direct_2025
      - score_water_bau50
      - score_nearest_plant_dist
      - score_capacity_mw
      - sustainability_index_v1
    """
    if config is None:
        config = SustainIndexConfig()

    required = [config.cfe_col, config.ci_col, config.water_col, config.dist_col, config.cap_col]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    out = df.copy()

    # Compute bounds if not provided
    if bounds is None:
        bounds = {
            "cfe": robust_bounds(out[config.cfe_col], config.p_low, config.p_high),
            "ci": robust_bounds(out[config.ci_col], config.p_low, config.p_high),
            "water": robust_bounds(out[config.water_col], config.p_low, config.p_high),
            "cap": robust_bounds(out[config.cap_col], config.p_low, config.p_high),
        }

    cfe_lo, cfe_hi = bounds["cfe"]
    ci_lo, ci_hi = bounds["ci"]
    w_lo, w_hi = bounds["water"]
    cap_lo, cap_hi = bounds["cap"]

    # Component scores (0–1)
    score_cfe = robust_scale_series(out[config.cfe_col], cfe_lo, cfe_hi, higher_is_better=True)
    score_ci = robust_scale_series(out[config.ci_col], ci_lo, ci_hi, higher_is_better=False)
    score_water = robust_scale_series(out[config.water_col], w_lo, w_hi, higher_is_better=False)

    d = pd.to_numeric(out[config.dist_col], errors="coerce").astype(float)
    score_dist = np.exp(-d / float(config.tau_km))

    score_cap = robust_scale_series(out[config.cap_col], cap_lo, cap_hi, higher_is_better=True)

    # Final weighted index
    idx = (
        config.weights["score_cfe_2025"] * score_cfe +
        config.weights["score_ci_direct_2025"] * score_ci +
        config.weights["score_water_bau50"] * score_water +
        config.weights["score_nearest_plant_dist"] * score_dist +
        config.weights["score_capacity_mw"] * score_cap
    )

    if add_component_scores:
        out["score_cfe_2025"] = score_cfe
        out["score_ci_direct_2025"] = score_ci
        out["score_water_bau50"] = score_water
        out["score_nearest_plant_dist"] = score_dist
        out["score_capacity_mw"] = score_cap

    out["sustainability_index_v1"] = idx

    return out, bounds
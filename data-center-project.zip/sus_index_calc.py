# main_optimize_grid.py
# Runs a 3-stage grid optimization (coarse -> medium -> fine) and writes:
# 1) stage_candidates_all.csv   (ALL candidates evaluated across all stages; includes stage + score)
# 2) stage_hotspots.csv         (the hotspots chosen for refinement at each stage)
# 3) stage_best_topN.csv        (top N feasible candidates from the final stage)
#
# Assumes you have:
# - sustainability_index.py (helper module from earlier)
# - datasets folder with geojson/gdb/shapefiles/csvs

import os
import json
import numpy as np
import pandas as pd

from shapely.geometry import shape, Point
from shapely.ops import unary_union
from shapely.strtree import STRtree

import fiona
from pyproj import CRS, Transformer
from sklearn.neighbors import BallTree

from sustainability_index import compute_sustainability_index_v1, SustainIndexConfig


# ============================
# CONFIG: Paths
# ============================
DATA_DIR = "datasets"

ENERGY_ZONES_GEOJSON = os.path.join(DATA_DIR, "conus_electricity_map.geojson")
REGION_METRICS_CSV   = os.path.join(DATA_DIR, "region_growth_and_annual_averages_2023_2025.csv")

WATERSTRESS_GDB      = os.path.join(DATA_DIR, "Aq40_Y2023D07M05.gdb")  # <-- set your gdb path
WATER_LAYER          = "future_annual"
WATER_METRICS_CSV    = os.path.join(DATA_DIR, "waterstress_us.csv")  # contains pfaf_id + water_risk_index_bau50 or inputs to compute it

RENEW_PLANTS_CSV     = os.path.join(DATA_DIR, "usa_renewablepower_plant_data.csv")  # needs lat/lon + type + capacity
URBAN_POLYGONS_PATH  = os.path.join(DATA_DIR, "urban_areas/tl_2025_us_uac20.shp")  # <-- set your urban polygon file

# Output files (plot-friendly)
OUT_ALL_CANDIDATES = "stage_candidates_all.csv"
OUT_HOTSPOTS       = "stage_hotspots.csv"
OUT_TOP_FINAL      = "stage_best_topN.csv"


# ============================
# CONFIG: Optimization settings
# ============================
URBAN_MIN_MILES = 1.0
MI_TO_KM = 1.609344

# Three stages: (grid_km, refine_radius_km, n_hotspots_to_refine, top_fraction_to_choose_hotspots)
STAGES = [
    dict(stage=1, grid_km=30.0, refine_radius_km=120.0, n_hotspots=25, hotspot_top_frac=0.01),
    dict(stage=2, grid_km=10.0, refine_radius_km=40.0,  n_hotspots=20, hotspot_top_frac=0.01),
    dict(stage=3, grid_km=3.0,  refine_radius_km=15.0,  n_hotspots=10, hotspot_top_frac=0.01),
]

TOP_N_FINAL = 200  # save top N final candidates


# ============================
# Helpers: loading + spatial queries
# ============================
def detect_geojson_crs(gj: dict) -> CRS:
    crs_name = (gj.get("crs") or {}).get("properties", {}).get("name")
    if crs_name and "EPSG::" in crs_name:
        try:
            epsg = int(crs_name.split("EPSG::")[-1])
            return CRS.from_epsg(epsg)
        except Exception:
            pass
    return CRS.from_epsg(4326)


def load_energy_zones(geojson_path):
    with open(geojson_path, "r") as f:
        gj = json.load(f)

    zones_crs = detect_geojson_crs(gj)

    zone_geoms = {}
    zone_desc  = {}

    for feat in gj.get("features", []):
        props = feat.get("properties") or {}
        zid = props.get("zoneName")
        if not zid:
            continue
        geom = feat.get("geometry")
        if not geom:
            continue
        g = shape(geom)
        zone_geoms.setdefault(zid, []).append(g)
        zone_desc.setdefault(zid, props.get("zoneDesc") or "")

    zone_ids = sorted(zone_geoms.keys())
    zones_geoms = [unary_union(zone_geoms[z]) for z in zone_ids]
    zone_descs = [zone_desc[z] for z in zone_ids]

    tree = STRtree(zones_geoms)
    zones_union = unary_union(zones_geoms)
    return zones_crs, tree, zones_geoms, zone_ids, zone_descs, zones_union


def point_to_energy_zone(lat, lon, transformer, tree, zones_geoms, zone_ids, zone_descs):
    x, y = transformer.transform(lon, lat)
    p = Point(x, y)
    hits = tree.query(p)

    if len(hits) == 0:
        return None, None

    # Handle Shapely 2.x (indices) vs 1.8 (geometries)
    if isinstance(hits[0], (int, np.integer)):
        # Shapely 2.x: indices
        for idx in hits:
            g = zones_geoms[int(idx)]
            if g.covers(p):
                return zone_ids[int(idx)], zone_descs[int(idx)]
    else:
        # Shapely 1.8 fallback: geometries
        for g in hits:
            if g.covers(p):
                i = zones_geoms.index(g)
                return zone_ids[i], zone_descs[i]

    return None, None


def load_water_basins(gdb_path, layer, pfaf_keep_set):
    basins_geoms = []
    basins_pfafs = []

    with fiona.open(gdb_path, layer=layer) as src:
        basins_crs = CRS.from_wkt(src.crs_wkt) if src.crs_wkt else CRS.from_user_input(src.crs)
        for feat in src:
            props = feat.get("properties") or {}
            pf = props.get("pfaf_id")
            if pf is None:
                continue
            try:
                pf = int(pf)
            except Exception:
                continue
            if pfaf_keep_set is not None and pf not in pfaf_keep_set:
                continue
            geom = feat.get("geometry")
            if not geom:
                continue
            basins_geoms.append(shape(geom))
            basins_pfafs.append(pf)

    tree = STRtree(basins_geoms)
    return basins_crs, tree, basins_geoms, basins_pfafs


def point_to_pfaf(lat, lon, transformer, tree, basins_geoms, basins_pfafs):
    x, y = transformer.transform(lon, lat)
    p = Point(x, y)
    hits = tree.query(p)

    if len(hits) == 0:
        return None

    # Handle Shapely 2.x (indices) vs 1.8 (geometries)
    if isinstance(hits[0], (int, np.integer)):
        # Shapely 2.x: indices
        for idx in hits:
            g = basins_geoms[int(idx)]
            if g.covers(p):
                return basins_pfafs[int(idx)]
    else:
        # Shapely 1.8 fallback: geometries
        for g in hits:
            if g.covers(p):
                i = basins_geoms.index(g)
                return basins_pfafs[i]

    return None


def load_urban_polygons(urban_path):
    import geopandas as gpd
    gdf = gpd.read_file(urban_path)
    urban_geoms = [g for g in gdf.geometry if g is not None and not g.is_empty]
    tree = STRtree(urban_geoms)
    return CRS.from_user_input(gdf.crs), tree, urban_geoms


def point_to_urban_distance_km(lat, lon, transformer, urban_tree, urban_geoms):
    x, y = transformer.transform(lon, lat)
    p = Point(x, y)
    hits = urban_tree.query(p)

    if len(hits) == 0:
        return np.inf

    # Handle Shapely 2.x (indices) vs 1.8 (geometries)
    if isinstance(hits[0], (int, np.integer)):
        # Shapely 2.x: indices
        d_m = min(urban_geoms[int(i)].distance(p) for i in hits)
    else:
        # Shapely 1.8 fallback: geometries
        d_m = min(g.distance(p) for g in hits)

    return float(d_m) / 1000.0


def build_renewable_balltree(plants_df, lat_col="lat", lon_col="lon"):
    lat = np.deg2rad(plants_df[lat_col].astype(float).to_numpy())
    lon = np.deg2rad(plants_df[lon_col].astype(float).to_numpy())
    coords = np.c_[lat, lon]
    tree = BallTree(coords, metric="haversine")
    return tree


def nearest_renewable(lat, lon, tree, plants_df):
    R = 6371.0088
    pt = np.deg2rad([[lat, lon]])
    dist_rad, ind = tree.query(pt, k=1)
    d_km = float(dist_rad[0, 0] * R)
    i = int(ind[0, 0])
    return d_km, plants_df.iloc[i]


# ============================
# Candidate generation functions
# ============================
def grid_points_in_bbox(lat_min, lat_max, lon_min, lon_max, step_km):
    """
    Generate a roughly-uniform lat/lon grid within bbox.
    Uses an approximation: 1 deg lat ~= 111 km, 1 deg lon ~= 111 km * cos(lat_mid)
    Good enough for candidate generation; exact distances handled later.
    """
    lat_mid = 0.5 * (lat_min + lat_max)
    dlat = step_km / 111.0
    dlon = step_km / (111.0 * max(0.2, np.cos(np.deg2rad(lat_mid))))  # avoid near-zero

    lats = np.arange(lat_min, lat_max + dlat, dlat)
    lons = np.arange(lon_min, lon_max + dlon, dlon)

    for lat in lats:
        for lon in lons:
            yield float(lat), float(lon)


def bbox_around_hotspot(lat, lon, radius_km):
    dlat = radius_km / 111.0
    dlon = radius_km / (111.0 * max(0.2, np.cos(np.deg2rad(lat))))
    return (lat - dlat, lat + dlat, lon - dlon, lon + dlon)


def generate_candidates_stage(zones_union_wgs84, stage_cfg, hotspots=None):
    """
    Stage 1: generate across union bbox (coarse)
    Stage 2+: generate within bboxes around hotspots
    Returns a list of (lat, lon, stage, hotspot_id)
    """
    grid_km = stage_cfg["grid_km"]
    stage = stage_cfg["stage"]

    candidates = []

    if hotspots is None or len(hotspots) == 0:
        # stage 1 global bbox
        minx, miny, maxx, maxy = zones_union_wgs84.bounds  # lon/lat if in EPSG:4326
        # If union is not WGS84, caller will pass WGS84 union. (We ensure below.)
        for lat, lon in grid_points_in_bbox(miny, maxy, minx, maxx, grid_km):
            candidates.append((lat, lon, stage, None))
        return candidates

    # refine around hotspots
    radius_km = stage_cfg["refine_radius_km"]
    for hid, (h_lat, h_lon) in enumerate(hotspots, start=1):
        lat_min, lat_max, lon_min, lon_max = bbox_around_hotspot(h_lat, h_lon, radius_km)
        for lat, lon in grid_points_in_bbox(lat_min, lat_max, lon_min, lon_max, grid_km):
            candidates.append((lat, lon, stage, hid))

    return candidates


def choose_hotspots(df_scored, stage_cfg):
    """
    Choose hotspots from the best-performing candidates of this stage.
    - Takes top fraction by sustainability_index_v1
    - Then downsamples to n_hotspots by simple spacing heuristic
    """
    n_hotspots = stage_cfg["n_hotspots"]
    top_frac = stage_cfg["hotspot_top_frac"]

    d = df_scored.dropna(subset=["sustainability_index_v1"]).copy()
    if d.empty:
        return []

    d = d.sort_values("sustainability_index_v1", ascending=False)
    k = max(10, int(len(d) * top_frac))
    d = d.head(k)

    # Simple "diversity" selection: greedy keep points that are far from existing hotspots
    selected = []
    min_sep_km = stage_cfg["refine_radius_km"] * 0.5

    def approx_km(a, b):
        # quick approximate distance in km
        lat1, lon1 = a
        lat2, lon2 = b
        dlat = (lat2 - lat1) * 111.0
        dlon = (lon2 - lon1) * 111.0 * np.cos(np.deg2rad(0.5 * (lat1 + lat2)))
        return float(np.sqrt(dlat * dlat + dlon * dlon))

    for _, row in d.iterrows():
        cand = (float(row["lat"]), float(row["lon"]))
        if not selected:
            selected.append(cand)
        else:
            if all(approx_km(cand, s) >= min_sep_km for s in selected):
                selected.append(cand)
        if len(selected) >= n_hotspots:
            break

    return selected


# ============================
# Evaluation of candidates (compute all inputs needed for sustainability_index_v1)
# ============================
def evaluate_candidates(
    candidates,
    *,
    # spatial engines
    to_zones, zones_tree, zones_geoms, zone_ids, zone_descs,
    to_basins, basins_tree, basins_geoms, basins_pfafs,
    to_urban, urban_tree, urban_geoms,
    plant_tree, plants_df,
    reg_lookup, ws_lookup,
    urban_min_km
):
    rows = []

    for lat, lon, stage, hotspot_id in candidates:
        # energy zone
        zone_id, zone_name = point_to_energy_zone(lat, lon, to_zones, zones_tree, zones_geoms, zone_ids, zone_descs)
        if zone_id is None or zone_id not in reg_lookup:
            continue

        # urban distance constraint (still record distance even if infeasible)
        d_urban_km = point_to_urban_distance_km(lat, lon, to_urban, urban_tree, urban_geoms)
        feasible = d_urban_km >= urban_min_km
        if not feasible:
            continue  # hard constraint for optimization search

        # water basin
        pfaf = point_to_pfaf(lat, lon, to_basins, basins_tree, basins_geoms, basins_pfafs)
        if pfaf is None or pfaf not in ws_lookup:
            continue

        # nearest renewable
        d_plant_km, plant_row = nearest_renewable(lat, lon, plant_tree, plants_df)
        plant_type = plant_row.get("primary_fuel", None)
        plant_cap_mw = float(plant_row.get("capacity_mw", np.nan))

        # region metrics
        zm = reg_lookup[zone_id]
        cfe_2025 = float(zm["carbon_free_energy_percentage_cfe_avg_2025"])
        ci_2025  = float(zm["carbon_intensity_gco_eq_kwh_direct_avg_2025"])

        # water metric
        water = float(ws_lookup[pfaf]["water_risk_index_bau50"])

        rows.append({
            "stage": stage,
            "hotspot_id": hotspot_id,
            "lat": lat,
            "lon": lon,
            "energy_zone_id": zone_id,
            "energy_zone_name": zone_name,
            "pfaf_id": int(pfaf),
            "dist_to_urban_km": d_urban_km,
            "nearest_plant_dist_km": d_plant_km,
            "nearest_plant_type": plant_type,
            "nearest_plant_capacity_mw": plant_cap_mw,
            # columns expected by sustainability_index.py helper:
            "carbon_free_energy_percentage_cfe_avg_2025": cfe_2025,
            "carbon_intensity_gco_eq_kwh_direct_avg_2025": ci_2025,
            "water_risk_index_bau50": water,
        })

    return pd.DataFrame(rows)


# ============================
# MAIN: 3-stage optimization runner
# ============================
def run_three_stage_optimization():
    # ---- Load zone metrics ----
    reg = pd.read_csv(REGION_METRICS_CSV)
    reg["Zone id"] = reg["Zone id"].astype(str)
    reg_lookup = reg.set_index("Zone id").to_dict(orient="index")

    # ---- Load water metrics (US-only) ----
    ws = pd.read_csv(WATER_METRICS_CSV)
    ws["pfaf_id"] = pd.to_numeric(ws["pfaf_id"], errors="coerce").astype("Int64")

    if "water_risk_index_bau50" not in ws.columns:
        ws["water_risk_index_bau50"] = (
            0.6 * pd.to_numeric(ws["bau50_ws_x_s"], errors="coerce") +
            0.3 * pd.to_numeric(ws["bau50_wd_x_s"], errors="coerce") +
            0.1 * pd.to_numeric(ws["bau50_sv_x_s"], errors="coerce")
        )

    ws = ws.dropna(subset=["pfaf_id", "water_risk_index_bau50"]).copy()
    ws["pfaf_id"] = ws["pfaf_id"].astype(int)
    pfaf_keep = set(ws["pfaf_id"].tolist())
    ws_lookup = ws.set_index("pfaf_id").to_dict(orient="index")

    # ---- Renewable plants + BallTree ----
    plants = pd.read_csv(RENEW_PLANTS_CSV)
    # Adjust names if needed:
    plants = plants.rename(columns={
        "latitude": "lat",
        "longitude": "lon",
        "capacity_mw": "capacity_mw",
        "primary_fuel": "primary_fuel",
    })
    plant_tree = build_renewable_balltree(plants, lat_col="lat", lon_col="lon")

    # ---- Energy zones polygons ----
    zones_crs, zones_tree, zones_geoms, zone_ids, zone_descs, zones_union = load_energy_zones(ENERGY_ZONES_GEOJSON)

    # Ensure we have a WGS84 union for bbox generation
    # If zones_crs != EPSG:4326, reproject union bounds by transforming its bounds corners.
    if zones_crs.to_epsg() != 4326:
        # zones_union is in zones_crs; build a rough WGS84 bbox polygon from its bounds
        to_wgs84 = Transformer.from_crs(zones_crs, CRS.from_epsg(4326), always_xy=True)
        minx, miny, maxx, maxy = zones_union.bounds
        lon1, lat1 = to_wgs84.transform(minx, miny)
        lon2, lat2 = to_wgs84.transform(maxx, maxy)
        zones_union_wgs84 = shape({
            "type": "Polygon",
            "coordinates": [[
                (min(lon1, lon2), min(lat1, lat2)),
                (max(lon1, lon2), min(lat1, lat2)),
                (max(lon1, lon2), max(lat1, lat2)),
                (min(lon1, lon2), max(lat1, lat2)),
                (min(lon1, lon2), min(lat1, lat2)),
            ]]
        })
    else:
        zones_union_wgs84 = zones_union  # already WGS84

    to_zones = Transformer.from_crs(CRS.from_epsg(4326), zones_crs, always_xy=True)

    # ---- Water basins polygons ----
    basins_crs, basins_tree, basins_geoms, basins_pfafs = load_water_basins(WATERSTRESS_GDB, WATER_LAYER, pfaf_keep)
    to_basins = Transformer.from_crs(CRS.from_epsg(4326), basins_crs, always_xy=True)

    # ---- Urban polygons ----
    urban_crs, urban_tree, urban_geoms = load_urban_polygons(URBAN_POLYGONS_PATH)
    to_urban = Transformer.from_crs(CRS.from_epsg(4326), urban_crs, always_xy=True)

    urban_min_km = URBAN_MIN_MILES * MI_TO_KM

    # ---- Sustainability index config ----
    sconfig = SustainIndexConfig(tau_km=25.0)

    all_stage_results = []
    hotspots_log = []

    # Carry hotspots forward
    hotspots = None

    # IMPORTANT: bounds consistency
    # We compute scaling bounds on Stage 1 results, then reuse them for later stages
    bounds_used = None

    for st in STAGES:
        # 1) Generate candidates for this stage
        candidates = generate_candidates_stage(zones_union_wgs84, st, hotspots=hotspots)

        # 2) Evaluate candidates -> metrics table
        df_stage = evaluate_candidates(
            candidates,
            to_zones=to_zones, zones_tree=zones_tree, zones_geoms=zones_geoms, zone_ids=zone_ids, zone_descs=zone_descs,
            to_basins=to_basins, basins_tree=basins_tree, basins_geoms=basins_geoms, basins_pfafs=basins_pfafs,
            to_urban=to_urban, urban_tree=urban_tree, urban_geoms=urban_geoms,
            plant_tree=plant_tree, plants_df=plants,
            reg_lookup=reg_lookup, ws_lookup=ws_lookup,
            urban_min_km=urban_min_km,
        )

        if df_stage.empty:
            print(f"Stage {st['stage']}: no feasible candidates.")
            hotspots = []
            continue

        # 3) Compute sustainability index (reuse bounds for comparability across stages)
        df_stage_scored, bounds_used = compute_sustainability_index_v1(
            df_stage,
            config=sconfig,
            bounds=bounds_used,          # Stage 1 computes bounds; Stage 2/3 reuse them
            add_component_scores=True,
        )

        all_stage_results.append(df_stage_scored)

        # 4) Pick hotspots for next stage
        hotspots = choose_hotspots(df_stage_scored, st)
        for i, (h_lat, h_lon) in enumerate(hotspots, start=1):
            hotspots_log.append({
                "stage": st["stage"],
                "hotspot_rank": i,
                "lat": h_lat,
                "lon": h_lon,
                "grid_km": st["grid_km"],
                "refine_radius_km": st["refine_radius_km"],
            })

        print(f"Stage {st['stage']}: evaluated {len(df_stage_scored)} feasible points; next hotspots: {len(hotspots)}")

    # ---- Combine + write outputs ----
    if not all_stage_results:
        raise RuntimeError("No candidates were evaluated across stages.")

    all_df = pd.concat(all_stage_results, ignore_index=True)
    all_df.to_csv(OUT_ALL_CANDIDATES, index=False)

    hotspots_df = pd.DataFrame(hotspots_log)
    hotspots_df.to_csv(OUT_HOTSPOTS, index=False)

    # final stage top N
    final_stage = max(s["stage"] for s in STAGES)
    final_df = all_df[all_df["stage"] == final_stage].copy()
    final_df = final_df.sort_values("sustainability_index_v1", ascending=False).head(TOP_N_FINAL)
    final_df.to_csv(OUT_TOP_FINAL, index=False)

    print("Wrote:", OUT_ALL_CANDIDATES)
    print("Wrote:", OUT_HOTSPOTS)
    print("Wrote:", OUT_TOP_FINAL)


if __name__ == "__main__":
    run_three_stage_optimization()